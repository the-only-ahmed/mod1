g++ -F ~/Library/Frameworks -framework SDL2 -I ~/Library/Frameworks/SDL2.framework/Headers -framework OpenGL *.cpp tools/*.cpp
real-time eulerian water simulation 
